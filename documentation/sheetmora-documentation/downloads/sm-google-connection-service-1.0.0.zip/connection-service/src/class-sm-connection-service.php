<?php
/** OAuth broker: no WooCommerce orders are received, stored or forwarded here. */
declare(strict_types=1);

namespace SMConnect;

final class ServiceError extends \RuntimeException
{
    public int $status;

    public function __construct(string $message, int $status = 400)
    {
        parent::__construct($message);
        $this->status = $status;
    }
}

final class Service
{
    private \PDO $db;
    private string $key;
    private array $config;
    private $http;
    public const SCOPE = 'openid email https://www.googleapis.com/auth/drive.file';

    public function __construct(\PDO $db, string $key, array $config, ?callable $http = null)
    {
        if (strlen($key) !== 32 || empty($config['client_id']) || empty($config['client_secret']) || !self::publicHttps($config['url'] ?? '') || parse_url($config['url'], PHP_URL_QUERY)) {
            throw new ServiceError('invalid_service_configuration', 500);
        }
        $this->db = $db;
        $this->key = $key;
        $this->config = $config;
        $this->http = $http ?? [self::class, 'http'];
        $db->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
        $db->exec('PRAGMA busy_timeout=5000');
        $db->exec('PRAGMA journal_mode=WAL');
        $db->exec('CREATE TABLE IF NOT EXISTS records (bucket TEXT NOT NULL, id TEXT NOT NULL, document TEXT NOT NULL, expires INTEGER NOT NULL, PRIMARY KEY(bucket,id))');
        $statement = $db->prepare('DELETE FROM records WHERE expires < ?');
        $statement->execute([time()]);
    }

    public static function fromEnvironment(): self
    {
        $directory = realpath((string)getenv('SM_STORAGE_DIR'));
        $documentRoot = realpath($_SERVER['DOCUMENT_ROOT'] ?? __DIR__ . '/..');
        if (!$directory || !is_dir($directory) || !is_writable($directory) || ($documentRoot && strncmp($directory . DIRECTORY_SEPARATOR, $documentRoot . DIRECTORY_SEPARATOR, strlen($documentRoot) + 1) === 0)) {
            throw new ServiceError('private_storage_required', 500);
        }
        $key = base64_decode((string)getenv('SM_STORAGE_KEY'), true);
        if (!is_string($key)) {
            throw new ServiceError('invalid_storage_key', 500);
        }
        return new self(new \PDO('sqlite:' . $directory . '/connections.sqlite'), $key, [
            'url' => (string)getenv('SM_SERVICE_URL'),
            'client_id' => (string)getenv('SM_GOOGLE_CLIENT_ID'),
            'client_secret' => (string)getenv('SM_GOOGLE_CLIENT_SECRET'),
        ]);
    }

    public static function publicHttps(string $url): bool
    {
        $parts = parse_url($url);
        if (!is_array($parts) || ($parts['scheme'] ?? '') !== 'https' || empty($parts['host']) || isset($parts['user']) || isset($parts['pass']) || isset($parts['port']) || isset($parts['fragment'])) {
            return false;
        }
        $host = strtolower($parts['host']);
        return $host !== 'localhost' && strpos($host, '.') !== false && !filter_var($host, FILTER_VALIDATE_IP) && preg_match('/^[a-z0-9.-]+$/D', $host) === 1;
    }

    private static function text(array $input, string $name, int $maximum = 4096): string
    {
        $value = $input[$name] ?? '';
        if (!is_string($value) || strlen($value) > $maximum || preg_match('/[\x00-\x1f\x7f]/', $value)) {
            throw new ServiceError('invalid_' . $name);
        }
        return $value;
    }

    private static function random(): string
    {
        return bin2hex(random_bytes(32));
    }

    private function encrypt(array $data): string
    {
        $nonce = random_bytes(12);
        $tag = '';
        $encrypted = openssl_encrypt(json_encode($data, JSON_THROW_ON_ERROR), 'aes-256-gcm', $this->key, OPENSSL_RAW_DATA, $nonce, $tag, 'sm-connect-v1');
        if ($encrypted === false) {
            throw new ServiceError('storage_encryption_failed', 500);
        }
        return base64_encode($nonce . $tag . $encrypted);
    }

    private function decrypt(string $document): array
    {
        $raw = base64_decode($document, true);
        if ($raw === false || strlen($raw) < 29) {
            throw new ServiceError('invalid_connection', 401);
        }
        $json = openssl_decrypt(substr($raw, 28), 'aes-256-gcm', $this->key, OPENSSL_RAW_DATA, substr($raw, 0, 12), substr($raw, 12, 16), 'sm-connect-v1');
        $data = is_string($json) ? json_decode($json, true) : null;
        if (!is_array($data)) {
            throw new ServiceError('invalid_connection', 401);
        }
        return $data;
    }

    private function put(string $bucket, string $token, array $data, int $lifetime): void
    {
        $statement = $this->db->prepare('INSERT OR REPLACE INTO records (bucket,id,document,expires) VALUES (?,?,?,?)');
        $statement->execute([$bucket, hash('sha256', $token), $this->encrypt($data), time() + $lifetime]);
    }

    private function get(string $bucket, string $token): array
    {
        if (preg_match('/^[a-f0-9]{64}$/D', $token) !== 1) {
            throw new ServiceError('invalid_connection', 401);
        }
        $statement = $this->db->prepare('SELECT document FROM records WHERE bucket=? AND id=? AND expires>=?');
        $statement->execute([$bucket, hash('sha256', $token), time()]);
        $document = $statement->fetchColumn();
        if (!is_string($document)) {
            throw new ServiceError('invalid_connection', 401);
        }
        return $this->decrypt($document);
    }

    private function take(string $bucket, string $token): array
    {
        $this->db->exec('BEGIN IMMEDIATE');
        try {
            $data = $this->get($bucket, $token);
            $this->remove($bucket, $token);
            $this->db->exec('COMMIT');
            return $data;
        } catch (\Throwable $error) {
            $this->db->exec('ROLLBACK');
            throw $error;
        }
    }

    private function remove(string $bucket, string $token): void
    {
        $statement = $this->db->prepare('DELETE FROM records WHERE bucket=? AND id=?');
        $statement->execute([$bucket, hash('sha256', $token)]);
    }

    public static function http(string $url, array $body): array
    {
        // URLs come only from the fixed Google endpoints below.
        $handle = curl_init($url);
        curl_setopt_array($handle, [CURLOPT_POST => true, CURLOPT_POSTFIELDS => http_build_query($body, '', '&', PHP_QUERY_RFC3986), CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => false, CURLOPT_CONNECTTIMEOUT => 5, CURLOPT_TIMEOUT => 20, CURLOPT_SSL_VERIFYPEER => true, CURLOPT_SSL_VERIFYHOST => 2, CURLOPT_HTTPHEADER => ['Content-Type: application/x-www-form-urlencoded'], CURLOPT_PROTOCOLS => CURLPROTO_HTTPS]);
        $response = curl_exec($handle);
        $status = curl_getinfo($handle, CURLINFO_RESPONSE_CODE);
        curl_close($handle);
        $data = is_string($response) && strlen($response) <= 65536 ? json_decode($response, true) : null;
        if ($status < 200 || $status >= 300 || !is_array($data)) {
            if (is_array($data) && ($data['error'] ?? '') === 'invalid_grant') {
                throw new ServiceError('invalid_connection', 401);
            }
            throw new ServiceError('provider_unavailable', 502);
        }
        return $data;
    }

    private function location(array $data, array $query): string
    {
        return $data['callback'] . '&' . http_build_query($query, '', '&', PHP_QUERY_RFC3986);
    }

    public function dispatch(string $action, string $method, array $input): array
    {
        $getActions = ['authorize', 'callback'];
        if ($method !== (in_array($action, $getActions, true) ? 'GET' : 'POST') || !in_array($action, ['start', 'authorize', 'callback', 'exchange', 'refresh', 'disconnect'], true)) {
            throw new ServiceError('invalid_action_or_method', 405);
        }
        if ($action === 'start') {
            $callback = self::text($input, 'callback', 2048);
            $site = self::text($input, 'site_url', 2048);
            $state = self::text($input, 'state', 64);
            $challenge = self::text($input, 'challenge', 43);
            if (!self::publicHttps($callback) || !self::publicHttps($site) || preg_match('/^[a-zA-Z0-9]{64}$/D', $state) !== 1 || preg_match('/^[a-zA-Z0-9_-]{43}$/D', $challenge) !== 1) {
                throw new ServiceError('invalid_start_request');
            }
            $expected = rtrim($site, '/') . '/wp-admin/admin-post.php?action=sm_google_callback';
            if (!hash_equals($expected, $callback) || parse_url($site, PHP_URL_QUERY)) {
                throw new ServiceError('invalid_callback');
            }
            $data = ['callback' => $callback, 'site_url' => $site, 'state' => $state, 'challenge' => $challenge];
            $request = self::random();
            $this->put('request', $request, $data, 600);
            return ['authorization_url' => $this->config['url'] . '?action=authorize&request=' . $request];
        }
        if ($action === 'authorize') {
            $data = $this->take('request', self::text($input, 'request', 64));
            $state = self::random();
            $this->put('oauth', $state, $data, 600);
            return ['redirect' => 'https://accounts.google.com/o/oauth2/v2/auth?' . http_build_query(['client_id' => $this->config['client_id'], 'redirect_uri' => $this->config['url'] . '?action=callback', 'response_type' => 'code', 'scope' => self::SCOPE, 'access_type' => 'offline', 'prompt' => 'consent', 'state' => $state], '', '&', PHP_QUERY_RFC3986)];
        }
        if ($action === 'callback') {
            $data = $this->take('oauth', self::text($input, 'state', 64));
            if (isset($input['error'])) {
                return ['redirect' => $this->location($data, ['state' => $data['state'], 'error' => 'access_denied'])];
            }
            $code = self::text($input, 'code');
            if (!$code) {
                throw new ServiceError('missing_code');
            }
            $tokens = call_user_func($this->http, 'https://oauth2.googleapis.com/token', ['code' => $code, 'client_id' => $this->config['client_id'], 'client_secret' => $this->config['client_secret'], 'redirect_uri' => $this->config['url'] . '?action=callback', 'grant_type' => 'authorization_code']);
            if (!is_string($tokens['refresh_token'] ?? null) || !is_string($tokens['access_token'] ?? null) || !in_array('https://www.googleapis.com/auth/drive.file', explode(' ', $tokens['scope'] ?? ''), true)) {
                return ['redirect' => $this->location($data, ['state' => $data['state'], 'error' => 'permission_required'])];
            }
            $ticket = self::random();
            $this->put('ticket', $ticket, ['request' => $data, 'tokens' => $tokens], 120);
            return ['redirect' => $this->location($data, ['state' => $data['state'], 'ticket' => $ticket])];
        }
        if ($action === 'exchange') {
            $ticket = self::text($input, 'ticket', 64);
            $verifier = self::text($input, 'verifier', 128);
            $record = $this->get('ticket', $ticket);
            $challenge = rtrim(strtr(base64_encode(hash('sha256', $verifier, true)), '+/', '-_'), '=');
            if (strlen($verifier) < 43 || !hash_equals($record['request']['challenge'], $challenge)) {
                throw new ServiceError('invalid_proof', 401);
            }
            $record = $this->take('ticket', $ticket);
            $connection = self::random();
            $this->put('connection', $connection, ['request' => $record['request'], 'refresh_token' => $record['tokens']['refresh_token']], 15552000);
            return ['connection_token' => $connection, 'access_token' => $record['tokens']['access_token'], 'expires_in' => min(3600, (int)($record['tokens']['expires_in'] ?? 3600))];
        }
        $connection = self::text($input, 'connection_token', 64);
        $record = $this->get('connection', $connection);
        if ($action === 'disconnect') {
            $this->remove('connection', $connection);
            try {
                call_user_func($this->http, 'https://oauth2.googleapis.com/revoke', ['token' => $record['refresh_token']]);
            } catch (\Throwable $error) {
                // Local revocation still succeeds when Google's endpoint is temporarily unavailable.
            }
            return ['success' => true];
        }
        try {
            $tokens = call_user_func($this->http, 'https://oauth2.googleapis.com/token', ['client_id' => $this->config['client_id'], 'client_secret' => $this->config['client_secret'], 'refresh_token' => $record['refresh_token'], 'grant_type' => 'refresh_token']);
        } catch (ServiceError $error) {
            if ($error->getMessage() === 'invalid_connection') {
                $this->remove('connection', $connection);
            }
            throw $error;
        }
        if (!is_string($tokens['access_token'] ?? null) || !$tokens['access_token']) {
            throw new ServiceError('provider_unavailable', 502);
        }
        $this->put('connection', $connection, $record, 15552000);
        return ['access_token' => $tokens['access_token'], 'expires_in' => min(3600, (int)($tokens['expires_in'] ?? 3600))];
    }
}
