# SheetMora Google connection service

Deploy this directory **separately** on an HTTPS PHP server. It is not part of the installable WordPress plugin ZIP and must not run from wp-content/plugins. The plugin also supports site-specific OAuth credentials when a hosted service is not wanted.

Requirements: PHP 8.0+, OpenSSL, cURL, PDO SQLite, HTTPS, and a writable private directory outside the document root. Configure your web server to disable directory listings, deny access to `src/`, and keep `display_errors` disabled. Configure request rate limiting for `action=start` (for example 10 requests/minute per IP) and request-size limits at the web server. Keep encrypted database backups private.

Set these environment variables on the server; never put actual secrets into the plugin:

- `SM_SERVICE_URL=https://connect-sheetmora.wpmethods.com/index.php` (no query string).
- `SM_GOOGLE_CLIENT_ID` and `SM_GOOGLE_CLIENT_SECRET` from a Google OAuth **Web application** client.
- `SM_STORAGE_DIR=/private/path/google-connect` (create it before starting).
- `SM_STORAGE_KEY`: base64 encoding of 32 random bytes. Generate with `php -r 'echo base64_encode(random_bytes(32));'`. Preserve this key securely; changing it invalidates saved connections.
- If TLS terminates at a trusted reverse proxy, set `SM_TRUST_HTTPS_PROXY=1` **only when the backend cannot be reached directly and the proxy enforces HTTPS**. The service deliberately does not trust arbitrary forwarded headers.

In Google Cloud, enable Google Sheets API and Google Drive API, configure branding/consent, and register exactly `https://connect-sheetmora.wpmethods.com/index.php?action=callback` as an authorized redirect URI. Request `openid`, `email`, and `https://www.googleapis.com/auth/drive.file`. Complete the applicable Google production/branding verification requirements and publish the app rather than leaving it in testing. Testing-mode grants can expire. Merchant stores must use HTTPS. Google authorization and token refresh do not call a license API. Pro feature entitlement and license management remain in the WordPress add-on.

On merchant sites set `SM_GOOGLE_CONNECT_URL` in wp-config.php or enter the URL in the Pro connection panel's developer setup. The service URL is public; the Google Client Secret and storage key remain server-side.

Flow: merchant administrator POSTs Connect Google → plugin creates session state bound to that administrator → service validates the HTTPS callback, state and handoff challenge and records a ten-minute OAuth request → Google consent → a two-minute one-time ticket returns to the same store callback → plugin exchanges that ticket using its PKCE handoff verifier → service returns an opaque connection handle and an access token. Google refresh tokens remain encrypted on this server. The plugin encrypts its connection handle and access token using WordPress salts. Google authorization codes/tickets are single-use. No Google tokens are placed in browser redirect URLs.

The refresh endpoint accepts only an unguessable connection handle and returns a short-lived Google token. Disconnect removes the handle and attempts Google revocation. Inactive records expire after 180 days. The broker never receives WooCommerce order data; orders travel directly between each store and Google Sheets. New broker records store the store URL, refresh token, and authorization/session metadata in authenticated encrypted records. License keys are not required or stored in new records. Publish a privacy policy explaining this processing and secure administrator access, database backups and operational logs. Avoid logging request bodies or query strings for OAuth routes.

Google references:
- https://developers.google.com/identity/protocols/oauth2/web-server
- https://developers.google.com/workspace/sheets/api/scopes
- https://developers.google.com/identity/protocols/oauth2/production-readiness/policy-compliance

Run the supplied standalone broker regression test before deployment. The included code is prepared for deployment; it does not create a Cloud project, provision a server, or claim Google verification has been completed.

The service accepts only the SheetMora encrypted record format. There is no previous-identity storage or credential fallback.


Deployment package 1.0.0: replace index.php and src/class-sm-connection-service.php together when deploying this package. Keep the existing environment variables, SM_STORAGE_KEY and private SQLite storage when replacing a working deployment. This service does not grant WordPress Pro entitlement.
