<?php
/** Standalone OAuth connection service. Deploy separately from the WordPress plugin. */
declare(strict_types=1);

require __DIR__ . '/src/class-sm-connection-service.php';

header('Cache-Control: no-store, private');
header('Pragma: no-cache');
header('Referrer-Policy: no-referrer');
header('X-Content-Type-Options: nosniff');
header("Content-Security-Policy: default-src 'none'; frame-ancestors 'none'");

try {
    if (($_SERVER['HTTPS'] ?? '') !== 'on' && getenv('SM_TRUST_HTTPS_PROXY') !== '1') {
        throw new \SMConnect\ServiceError('https_required', 400);
    }
    $input = [];
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    if ($method === 'POST') {
        if (stripos($_SERVER['CONTENT_TYPE'] ?? '', 'application/json') !== 0) {
            throw new \SMConnect\ServiceError('json_required', 415);
        }
        $raw = file_get_contents('php://input', false, null, 0, 32769);
        if (!is_string($raw) || strlen($raw) > 32768) {
            throw new \SMConnect\ServiceError('request_too_large', 413);
        }
        $input = json_decode($raw, true, 16);
        if (!is_array($input)) {
            throw new \SMConnect\ServiceError('invalid_json', 400);
        }
    } else {
        $input = $_GET;
    }
    $service = \SMConnect\Service::fromEnvironment();
    $result = $service->dispatch(is_string($_GET['action'] ?? null) ? $_GET['action'] : '', $method, $input);
    if (isset($result['redirect'])) {
        header('Location: ' . $result['redirect'], true, 302);
    } else {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($result, JSON_THROW_ON_ERROR);
    }
} catch (\SMConnect\ServiceError $error) {
    http_response_code($error->status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['error' => $error->getMessage()]);
} catch (\Throwable $error) {
    // Do not print exception text: provider responses or credentials can appear in exceptions.
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo '{"error":"service_unavailable"}';
}
